import React, { Component } from 'react'

class Blog extends Component {
  constructor(props){
    super(props)
    this.state={

    }
  }
  render () {
    return (
      <div id="">
          blog day
         </div>
    )
  }
}

export default Blog;
