import React, { Component } from 'react'

class AboutMe extends Component {
  constructor(props){
    super(props)
    this.state={

    }
  }
  render () {
    return (
      <div id="aboutme">
        <div className="aboutme__title">
          <div >
            About Me
          </div>
          <div className="Content">
            <p>Xoay là ai!!
             Xoay- thực ra là biệt danh hồi bé của mình thôi.Còn họ tên đầy đủ của mình là Nguyễn Mạnh Tiến.
             Sau 17 năm chơi game thì mình dành 1 năm lớp 12 để học với hi vọng đỗ vào trường đại học để tiếp tục chơi game.
             Nhưng không lên đại học mình không chơi game nữa vì mình bắt đầu tìm hiểu front-end và back-end .Nó như là tìm được đam mê vậy
             Mình viết mấy dòng này lúc này là 1h30 phút ngày 1/2/2020 này mồng 7 tết năm 2020.à quên hiện mình đang sinh viên trường đại học Hà nội khoa công nghệ thông tin năm thứ 2.
             chả biết viết gì nữa. mà nhân tiện mình chưa có ny nha !!
            </p>
          </div>
        </div>
         </div>
    )
  }
}

export default AboutMe;
